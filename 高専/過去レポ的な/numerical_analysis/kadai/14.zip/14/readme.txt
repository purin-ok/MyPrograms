コンパイル環境：BCC32C

コンパイル方法："bcc32c main.c NAbasic.c"と打つ

実行方法："main ファイル名.csv"と打つ
・課題用データの場合は　"main k14-input.csv"
・評価用データの場合は　"main k14-input_test.csv"　(予想のため，異なる場合もある)