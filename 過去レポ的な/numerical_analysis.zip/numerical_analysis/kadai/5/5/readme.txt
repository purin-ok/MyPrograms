コンパイル環境：BCC32C

コンパイル方法："bcc32c main.c NAbasic.c"と打つ

実行方法："main ファイル名.csv ファイル名.csv"と打つ（ファイル名はk5-input1.csv k5-input2.csvなど）