
NAbasic.cとNAbasic.hを使用

コンパイル環境：学校のPCの環境

コンパイル方法："bcc32c main.c NAbasic.c"と打つ

実行方法："main ファイル名.csv"と打つ（ファイル名はk1-inputなど）