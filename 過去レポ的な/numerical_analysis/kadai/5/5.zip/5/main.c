#include <math.h>
#include "NAbasic.h"

#define BUF 80

// 行列とベクトルの積を求める
double *matrix_times_vector(double **matrix, double *vector, int matrix_row, int matrix_col, int vector_len) {
    int i, j;
    double *ret = allocVector(vector_len);

    if (matrix_row != vector_len) {
        puts("計算できません.");
        return ret;
    }

    for (i = 0; i < matrix_row; i++) {
        for (j = 0; j < matrix_col; j++) {
            ret[i] += matrix[i][j] * vector[j];
        }
    }

    return ret;
}

// 行列を出力
void print_matrix(double **matrix, int row, int col) {
    int i, j;
    for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
            printf("%lf ", matrix[i][j]);
        }
        puts("");
    }
	puts("");
}

// ベクトルを出力
void print_vector(double *vector, int row) {
    int i;
    for (i = 0; i < row; i++) {
        printf("%lf ", vector[i]);
		puts("");
    }
	puts("");
}

// 行列の行交換
void swap_row(double **matrix, int row, int row1, int row2) {
    if (row1 < 0 || row1 >= row || row2 < 0 || row2 >= row) {
        puts("不適切な値です.");
        return;
    }

    double *tmp = matrix[row1];
    matrix[row1] = matrix[row2];
    matrix[row2] = tmp;
}

// LU分解 成功したら0を返す
int lu(
	double **A,
	double **L,
	double **U,
	double **P,
	int Arow
) {
	int i, j, k, pivot;
	double elim;

	for (i = 0; i < Arow; i++) {
		//pivot選択
		for (pivot = j = i; j < Arow; j++) {
			if (fabs(A[j][i]) > fabs(A[pivot][i])) {
				pivot = j;
			}
		}

		swap_row(A, Arow, i, pivot);
		swap_row(L, Arow, i, pivot);
		swap_row(U, Arow, i, pivot);
		swap_row(P, Arow, i, pivot);

		elim = A[i][i];
		if (0 == elim) {
			print_matrix(A, Arow, Arow);
			puts("LU分解できません.");
			return EXIT_FAILURE;
		}
		//Lを決める
		for (j = i; j < Arow; j++) {
			L[j][i] = A[j][i];
			L[j][i] /= elim;
		}

		//Uを決める
		for (j = i; j < Arow; j++) {
			U[i][j] = A[i][j];
		}

		//二次元配列前進消去
		for (k = i+1; k < Arow; k++) {
			elim = L[k][i];
			for (j = i; j < Arow; j++) {
				A[k][j] -= A[i][j] * elim;
			}
		}
	}

	return EXIT_SUCCESS;
}

// 前進消去
void forward_elimination(
	double **L,
	double *vector,
	double *Pb,
	int Arow
) {
	int i, j;

	for (i = 0; i < Arow; i++) {
		vector[i] = Pb[i] / L[i][i];
		for (j = 0; j < i; j++) {
			vector[i] -= vector[j] * L[i][j] / L[i][i];
		}
	}
}

// 後退代入
void backward_substitution(
	double **U,
	double *matrix,
	double *vector,
	int Arow
) {
	int i, j;

	for (i = Arow - 1; i >= 0; i--) {
		matrix[i] = vector[i] / U[i][i];
		for (j = i + 1; j < Arow; j++) {
			matrix[i] -= matrix[j] * U[i][j] / U[i][i];
		}
	}
}

// メモリ開放
void free_mems(
	double **A,
	double **b,
	double **L,
	double **U,
	double **P,
	double *matrix,
	double *Pb,
	double *vector
) {
	freeMatrix(A);
	freeMatrix(b);
	freeMatrix(L);
	freeMatrix(U);
	freeMatrix(P);

	freeVector(matrix);
	freeVector(Pb);
	freeVector(vector);
}

// 連立方程式を解く
void hiding(
	double **A,
	double **L,
	double **U,
	double **P,
	double **b,
	double *Pb,
	double *x,
	double *y,
	int Arow,
	int Acol,
	int brow,
	int bcol
) {
	Pb = matrix_times_vector(
		P, matrix2colVector(b, brow, bcol),
		Arow, Acol, brow
	);

	forward_elimination(L, y, Pb, Arow);
	backward_substitution(U, x, y, Arow);

	puts("X =");
	print_vector(x, Arow);

	free_mems(A, b, L, U, P, x, Pb, y);
}

int main(int argc, char **argv) {
	FILE *fin;
	double **A, **b, **L, **U, **P, *x, *Pb, *y;
	int i, Arow, Acol, brow, bcol;
	char file_name[BUF];

	//コマンドラインの処理
	if (argc != 3) {
		fprintf(stderr, "コマンドラインが不正です．\n");
		return EXIT_FAILURE;
	}
	// Aのcsvファイル読み込み
	if ((fin = fopen(argv[1], "r")) == NULL) {
		fprintf(stderr, "ファイルが存在しません．\n");
		return EXIT_FAILURE;
	}

	// csvからデータを読み込み
	A = csvRead(&Arow, &Acol, fin);

	if (Arow != Acol) {
		puts("A行列が正方行列ではありません.");
		return EXIT_FAILURE;
	}

	// 各変数のメモリ確保
	L = allocMatrix(Arow, Acol);
	U = allocMatrix(Arow, Acol);
	P = allocMatrix(Arow, Acol);
	x = allocVector(Arow);
	y = allocVector(Arow);

	// 単位行列P
	for (i = 0; i < Arow; i++) {
		P[i][i] = 1;
	}

	// LU分解が失敗したら終了
	if (lu(A, L, U, P, Arow)) {
		puts("LU分解に失敗しました.");
		return EXIT_FAILURE;
	}

	// 各行列の出力
	puts("L =");
	print_matrix(L, Arow, Acol);

	puts("U =");
	print_matrix(U, Arow, Acol);

	puts("P =");
	print_matrix(P, Arow, Acol);

	// bのcsvファイル読み込み
	if ((fin = fopen(argv[2], "r")) == NULL) {
		fprintf(stderr, "ファイルが存在しません．\n");
		return EXIT_FAILURE;
	}
	
	// csvからデータを読み込み
	b = csvRead(&brow, &bcol, fin);
	
	if (1 != bcol) {
		puts("bが列ベクトルではありません.");
		return EXIT_FAILURE;
	}

	// 連立方程式解く
	hiding(A, L, U, P, b, Pb, x, y, Arow, Acol, brow, bcol);

	return EXIT_SUCCESS;
}